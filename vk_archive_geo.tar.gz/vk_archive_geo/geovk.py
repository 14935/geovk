
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)


np.random.seed(42)

"""В качестве данных train и test использовались широты и долготы недвижимости, координаты растянуты равномерно до масштабов земли (т.е. от -90 до 90 градусов), а в качестве скора выбран медианный доход хозяйства в объекте недвижимоти (от дома до кварталла)"""

train = pd.read_csv('train.csv')

train.describe()

"""Предобработка данных. one hot кодирование столбца ocean_proximity, затем долготы и широты растягиваются до земных размеров (до (-90,+90) и (-180,+180))."""

features = pd.read_csv('features.csv')

features.head()

features.describe()

"""Для каждой строки из датафрейма сгенерированных признаков, находим наиболее близкий по координатам объект train. Затем обучаем и предсказываем таргет ближайшего объекта из обучающей выборки

cos(d) = sin(φА)·sin(φB) + cos(φА)·cos(φB)·cos(λА − λB),

где φА и φB — широты, λА, λB — долготы данных пунктов, d — расстояние между
"""

train.shape

X = list()
def find_nearest_row(row, df):

    lat1 = np.radians(row['lat'])
    lon1 = np.radians(row['lon'])
    lat2 = np.radians(df['lat'])
    lon2 = np.radians(df['lon'])

    distances = np.arccos(np.sin(lat1)*np.sin(lat2) + np.cos(lat1)*np.cos(lat2)*np.cos(lon1 - lon2))

    nearest_index = distances.idxmin()

    nearest_row = df.loc[nearest_index]
    return nearest_row

for index, row in train.iterrows():
    nearest_row = find_nearest_row(row, features)
    X.append(list(nearest_row))

X_train = pd.DataFrame(X)
X_train.head()

test = pd.read_csv('test.csv')

X_test = list()

for index, row in test.iterrows():
    nearest_row = find_nearest_row(row, features)
    X_test.append(list(nearest_row))

X_test = pd.DataFrame(X_test)
X_test.head()

y_train = train['score']
y_train

X_train.shape

from sklearn.decomposition import PCA

X_to = X_train.iloc[:, 2:366]

pca = PCA(n_components=50)
X_pca = pca.fit_transform(X_to)

df_pca = pd.DataFrame(X_pca)
X_train = pd.concat([X_train.iloc[:, :2].reset_index(drop=True), df_pca], axis=1)

X_train

y_train.shape

from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.datasets import make_regression
from sklearn.metrics import mean_absolute_error

rf_regressor = RandomForestRegressor()


param_grid = {
    'n_estimators': [300,400,500],
    'max_depth': [10,20,30],
}


grid_search = GridSearchCV(estimator=rf_regressor, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2, scoring='neg_mean_absolute_error')


grid_search.fit(X_train, y_train)


print("Наилучшие параметры модели:", grid_search.best_params_)


print("Лучшее значение метрики (neg_mean_absolute_error):", grid_search.best_score_)

best_rf_model = grid_search.best_estimator_

from joblib import dump
dump(best_rf_model, 'random_forest_regressor.joblib')

"""КОД ДЛЯ ГЕНЕРАЦИИ submission.csv"""

from joblib import load
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.datasets import make_regression
from sklearn.metrics import mean_absolute_error
from sklearn.decomposition import PCA

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Загрузка модели и данных
best_rf_model = load('random_forest_regressor.joblib')
features = pd.read_csv('features.csv')
test = pd.read_csv('test.csv')


def find_nearest_row(row, df):

    lat1 = np.radians(row['lat'])
    lon1 = np.radians(row['lon'])
    lat2 = np.radians(df['lat'])
    lon2 = np.radians(df['lon'])

    distances = np.arccos(np.sin(lat1)*np.sin(lat2) + np.cos(lat1)*np.cos(lat2)*np.cos(lon1 - lon2))

    nearest_index = distances.idxmin()

    nearest_row = df.loc[nearest_index]
    return nearest_row


#подготовка тестовой выборки
X_test = list()
for index, row in test.iterrows():
    nearest_row = find_nearest_row(row, features)
    X_test.append(list(nearest_row))
X_test = pd.DataFrame(X_test)
X_to = X_test.iloc[:, 2:366]

# Применяем PCA
pca = PCA(n_components=50)
X_pca = pca.fit_transform(X_to)
df_pca = pd.DataFrame(X_pca)
X_test = pd.concat([X_test.iloc[:, :2].reset_index(drop=True), df_pca], axis=1)
y_pred = best_rf_model.predict(X_test)
result_df = pd.DataFrame({'id':test['id'],'score':y_pred})
result_df.to_csv('submission.csv')


